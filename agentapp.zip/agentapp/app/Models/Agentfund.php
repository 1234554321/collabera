<?php

namespace App\Models;

use \Illuminate\Database\Eloquent\Model;

class Agentfund extends Model
{
    protected $table = 'agentfund';
}
