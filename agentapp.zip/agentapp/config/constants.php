<?php
return['All-privileges' => 'Root','Administrator'];