<?php
phpinfo();
?>

