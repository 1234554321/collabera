       
         <?php $__env->startSection('content'); ?>   
              <!--overview start-->
			 <div class="row">
				<div class="col-lg-12">
					<h3 class="page-header"><i class="fa fa-files-o"></i> Users</h3>
					<ol class="breadcrumb">
						<li><i class="fa fa-home"></i><a href="<?php echo e(URL::to(Helper::admin_slug())); ?>/dashboard">Home</a></li>
						<li><i class="fa fa-table"></i>Pages</li>
					</ol>
				</div>
			</div>
              <!-- page start -->              
              <div class="row">
              <?php if(Session::has('message')): ?>
              <div class="col-lg-12">
                 <div class="alert alert-success fade in"><?php echo e(Session::get('message')); ?></div>
                  </div>
                  <?php endif; ?>
                  <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                              All Users
                          </header>
                          <div class="table-responsive">
                            <table class="table">
                              <thead>
                                <tr>
                                  <th>No.</th>
                                  <th>Name</th>
                                  <th>email</th>
                                  <th>Role</th>
                                  <th>Action</th>
                                </tr>
                              </thead>
                              <tbody>
                              <?php foreach($users as $getuser): ?>
                                <tr>
                                  <td><?php echo $getuser->id; ?></td>
                                  <td><?php echo $getuser->name; ?></td>
                                  <td><?php echo $getuser->email; ?></td>
                                  <td>
                                   <?php if($getuser->role_id==1){ echo "Super admin"; }?>
                                   <?php if($getuser->role_id==2){ echo "Admin"; }?>
                                   <?php if($getuser->role_id==3){ echo "Editor"; }?>
                                   <?php if($getuser->role_id==4){ echo "Author"; }?>
                                   <?php if($getuser->role_id==5){ echo "subscribar"; }?>
                                  </td>
                                  <td>
                                  <div class="btn-group">
                           <a class="btn btn-success" href="<?php echo e(URL::to(Helper::admin_slug().'/user/edit',array($getuser->id))); ?>" title="Edit">
                                      <i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                  <!--<a class="btn btn-success" href="#"><i class="icon_check_alt2"></i></a>-->
                                      <a class="btn btn-danger" href="<?php echo e(URL::to(Helper::admin_slug().'/user/delete',array($getuser->id))); ?>" title="Delete"><i class="icon_close_alt2"></i></a>
                                  </div>
                                  </td>
                                </tr>
                                <?php endforeach; ?>
                              </tbody>
                            </table>
                          </div>
                      </section>
                       <?php echo $users->render(); ?>

                  </div>
              </div>
              <!-- page end-->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>