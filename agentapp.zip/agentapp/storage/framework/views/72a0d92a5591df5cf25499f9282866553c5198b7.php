<a href="<?php echo URL::to('student/new'); ?>">New Student</a>

<table>
   <thead>
     <th>Id</th>
     <th>name</th>
     <th>gender</th>
     <th>dob</th>
     <th>pob</th>
     <th>phone</th>
     <th>subjectname</th>
     <th>price</th>
     <th>shift</th>
     <th>year</th>
     <th>lavel</th>
     <th>email</th>
     <th>Action</th>
   </thead>
   
   <tbody>
   <?php foreach($students as $s): ?>
    <tr>
      <td><?php echo $s->id; ?></td>
      <td><?php echo $s->firstname." ".$s->lastname; ?></td>
      <td>
        <?php if($s->gender==1): ?>
         Male
        <?php else: ?>
         Female
        <?php endif; ?>
      </td>
      <td><?php echo $s->dob; ?></td>
      <td><?php echo $s->pob; ?></td>
      <td><?php echo $s->phone; ?></td>
      <td><?php echo $s->subjectname; ?></td>
      <td><?php echo $s->price; ?></td>
      <td><?php echo $s->shift; ?></td>
      <td><?php echo $s->year; ?></td>
      <td><?php echo $s->lavel; ?></td>
      <td><?php echo $s->email; ?></td>
      <td><a href="<?php echo e(URL::to('student/edit',array($s->id))); ?>">Edit</a> | <a href="<?php echo e(URL::to('student/delete',array($s->id))); ?>">Delete</a></td>
    </tr>
     <?php endforeach; ?>
   </tbody>
   
</table>