       
         <?php $__env->startSection('content'); ?>        
       <?php  if( Auth::check() ){ $userid = Auth::user()->id ; $userrolid = Auth::user()->role_id ;}else{ $userid = "";$userrolid =""; } ?>
              <!--overview start-->
			 <div class="row">
				<div class="col-lg-12">
         <div class="col-lg-2">
					<h3 class="Agent-header"><i class="fa fa-files-o"></i> Agent Order</h3>
          </div>
          <div class="col-lg-10">
             <div class="panel-body">
                <form class="form-inline" method="get" name="dfltsearch" id="dfltsearch" action="" role="form">
                        <div class="form-group">
                         <select class="form-control" id="ordersts" name="ordersts">
                           <option value="">status</option>
                           <option value="1">Pending</option>
                           <option value="2">Success</option>
                           <option value="3">Cancel</option>
                         </select>
                        </div>
                        <div class="form-group">
                         <select class="form-control" id="pymnttyp" name="pymnttyp">
                           <option value="">payment Type</option>
                           <option value="1">Cash</option>
                           <option value="2">Credit Card</option>
                         </select>
                        </div>
                        <div class="form-group">
                         <input type="text" class="form-control" id="datefrom" name="datefrom" value="<?php echo Input::get('datefrom'); ?>" placeholder="From Date">
                        </div>
                        <div class="form-group">
                         <input type="text" class="form-control" id="dateto" name="dateto" value="<?php echo Input::get('dateto'); ?>" placeholder="To Date">
                        </div>
                        <div class="form-group">
                         <input type="text" class="form-control" id="searchkey" name="searchkey" value="<?php echo Input::get('searchkey'); ?>" placeholder="Enter keyword">
                        </div>
                      <button type="submit" class="btn btn-primary">Search</button>
                    </form>
                  </div>
                </div>
				      </div>
			      </div>
            <?php 
                  $totalcrdt = "";
                  $agntorder = Helper::tableval('agent_order','agntid',$userid);
                  if($agntorder){
                       foreach ($agntorder as $key => $value) {
                          if($value->payment_mode==1){
                            $totalcrdt+=$value->total_amount;
                          }
                        }
                     }
                    
                  $agntfund = Helper::tableval('agentfund','agnt_id',$userid);
                  $totaldebit = "";
                    if($agntfund){
                       foreach ($agntfund as $key => $value) {
                          $totaldebit+=$value->agnt_fund;
                       }
                     }
                 
             ?>
              <!-- Agent start -->              
              <div class="row">
              <?php if(Session::has('message')): ?>
              <div class="col-lg-12">
                 <div class="alert alert-success fade in"><?php echo e(Session::get('message')); ?></div>
                  </div>
                  <?php endif; ?>
                  <div class="col-lg-12">
                  <?php if($userrolid==6): ?>
                   <strong>Available funds : Rs. <?php echo $totaldebit-$totalcrdt; ?></strong>
                   <?php endif; ?>
                      <section class="panel">
                          <header class="panel-heading">
                              Agent Order
                          </header>

                        <form name="itmmultidlt" action="<?php echo e(URL::to(Helper::admin_slug().'/agent/order/multidelete')); ?>" method="post">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                           <?php if($userrolid !=6): ?>
                          <input type="submit" name="multidlt" class="" value="delete" title="Delete Selected Items">
                           <?php endif; ?>
                          <div class="table-responsive">
                            <table class="table">
                              <thead>
                                <tr>
                                <?php if($userrolid !=6): ?>
                                  <th style="width: 4%;">
                                  <input type="checkbox" id="select_all"/>
                                  </th>
                                  <th>Agent Name</th>
                                  <?php endif; ?>
                                  <th>PNR/Booking No</th>
                                  <th>Order Date</th>
                                  <th>Payment Mode</th>
                                  <th>Cost Price</th>
                                  <th>Total Amount</th>
                                  <th>CC charges</th>
                                  <th>Credit card number</th>
                                  <th>Expiry date</th>
                                  <th>Name on the card</th>
                                  <th>Status</th>
                                  <th>Action</th>
                                </tr>
                              </thead>
                              <tbody>
                              <?php foreach($agentorders as $getAgentorder): ?>
                                <tr>
                                <?php if($userrolid !=6): ?>
                                  <td>
                                  <input name="multicheckbox[]" type="checkbox" id="multicheckbox[]" value="<?php echo $getAgentorder->Id; ?>" class="multicheckbox" >
                                  </td>
                                  <td><?php echo Helper::singlecolval('agent','agntu_id',$getAgentorder->agntid,'agnt_name'); ?></td>
                                  <?php endif; ?>
                                  <td><?php echo $getAgentorder->pnr_booking_no; ?></td>
                                  <td><?php echo substr($getAgentorder->created_at,0,10); ?></td>
                                  <td>
                                   <?php if($getAgentorder->payment_mode==1){
                                            echo "Cash";
                                          }else{
                                            echo "Credit Card";
                                          }
                                    ?>
                                  </td>
                                  <td>Rs. <?php echo $getAgentorder->cost_price; ?></td>
                                  <td>Rs. <?php echo $getAgentorder->total_amount; ?></td>
                                  <?php if($getAgentorder->credit_cardno !=""): ?>
                                  <td>Rs. <?php echo $getAgentorder->cc_charges; ?></td>
                                  <td><?php echo $getAgentorder->credit_cardno; ?></td>
                                  <td><?php echo $getAgentorder->expiry_date; ?></td>
                                  <td><?php echo $getAgentorder->card_holdername; ?></td>
                                  <?php else: ?>
                                   <td></td>
                                  <td></td>
                                  <td></td>
                                  <td></td>
                                  <?php endif; ?>
                                  <td>
                                  <?php if($getAgentorder->status==1): ?>
                                   <span class="label label-danger">
                                     Pending
                                     </span>
                                     <?php elseif($getAgentorder->status==2): ?>
                                     <span class="label label-success">
                                     Success
                                     </span>
                                     <?php else: ?>
                                     <span class="label label-danger">
                                     Cancel
                                    </span>
                                   <?php endif; ?>
                                  </td>
                                  <td>
                                  <?php if(Auth::user()->hasRole(Config::get('constants.All-privileges'))): ?> 
                                  <div class="btn-group">
                              <a class="btn btn-success btnsml" href="<?php echo e(URL::to(Helper::admin_slug().'/agent/order/edit',array($getAgentorder->Id))); ?>" title="Edit">
                                      <i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                  <!--<a class="btn btn-success" href="#"><i class="icon_check_alt2"></i></a>-->
                              <a class="btn btn-danger btnsml" href="<?php echo e(URL::to(Helper::admin_slug().'/agent/order/delete',array($getAgentorder->Id))); ?>" title="Delete"><i class="icon_close_alt2"></i></a>
                                  </div>
                                  <?php endif; ?>
                                  </td>
                                </tr>
                                <?php endforeach; ?>
                              </tbody>
                            </table>
                          </div>
                         </form>
                      </section>
                       <?php echo $agentorders->appends(Request::input())->links(); ?>

                  </div>
              </div>
              <!-- Agent end-->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>