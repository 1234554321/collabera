       
         <?php $__env->startSection('content'); ?>          
              <!--overview start-->
			 <div class="row">
				<div class="col-lg-12">
					<ol class="breadcrumb">
			     <li><i class="fa fa-home"></i><a href="<?php echo e(URL::to(Helper::admin_slug().'/dashboard')); ?>">Home</a></li>
						<li><i class="icon_document_alt"></i>Add Page</li>
					</ol>
				</div>
			</div>
              <!-- Form validations -->              
              <div class="row">
              <?php if(count($errors->all())>0): ?>
               <div class="col-lg-12">
                <div class="alert alert-block alert-danger fade in">
                      <?php echo HTML::ul($errors->all()); ?>

                     </div>
                    </div>
                   <?php endif; ?>
                  <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                              Add Page
                          </header>
                          
                          <div class="panel-body">
                         
                              <div class="form">
                                  <form class="form-validate form-horizontal" id="page_form" method="post" action="<?php echo e(URL::to(Helper::admin_slug().'/page/save')); ?>" enctype="multipart/form-data">
                                   <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                      <div class="form-group ">
                                          <label for="cname" class="control-label col-lg-2">Title <span class="required">*</span></label>
                                          <div class="col-lg-10">
                                              <input class="form-control" id="title" name="title" type="text" />
                                          </div>
                                      </div>
                                      <div class="form-group ">
                                          <label for="cemail" class="control-label col-lg-2">Content</label>
                                          <div class="col-lg-10">
                                              <textarea class="form-control " id="tinymce_textarea" name="cn"></textarea>
                                          </div>
                                      </div>
                                      <div class="form-group ">
                                          <label for="curl" class="control-label col-lg-2">Image</label>
                                          <div class="col-sm-6">
                                              <input class="form-control " id="img" type="file" name="img" />
                                          </div>
                                         <?php if(Session::has('error')): ?>
					<p class="errors"><?php echo Session::get('error'); ?></p>
					<?php endif; ?>
                                      </div>
                                      <div class="form-group ">
                                          <label for="cname" class="control-label col-lg-2">Meta Title </label>
                                          <div class="col-lg-10">
                                              <input class="form-control" id="mt" name="mt" type="text" />
                                          </div>
                                      </div> 
                                      <div class="form-group ">
                                          <label for="cname" class="control-label col-lg-2">Meta Keyword</label>
                                          <div class="col-lg-10">
                                              <input class="form-control" id="mk" name="mk" type="text" />
                                          </div>
                                      </div>                                      
                                      <div class="form-group ">
                                          <label for="ccomment" class="control-label col-lg-2">Meta Description</label>
                                          <div class="col-lg-10">
                                              <textarea class="form-control" id="md" name="md"></textarea>
                                          </div>
                                      </div>
                                      
                                      <div class="form-group ">
                                          <label for="ccomment" class="control-label col-lg-2">Status</label>
                                          <div class="col-sm-2">
                                             <select class="form-control m-bot15" name="sts">
                                              <option value="1">Active</option>
                                              <option value="2">Inactive</option>
                                          </select>
                                          </div>
                                      </div>
                                      <div class="form-group">
                                          <div class="col-lg-offset-2 col-lg-10">
                                              <button class="btn btn-primary" type="submit">Save</button>
                                          </div>
                                      </div>
                                  </form>
                              </div>

                          </div>
                      </section>
                  </div>
              </div>
              
              <!-- page end-->
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>