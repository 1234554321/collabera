       
         <?php $__env->startSection('content'); ?>          
              <!--overview start-->
			 <div class="row">
				<div class="col-lg-12">
					<ol class="breadcrumb">
						<li><i class="fa fa-home"></i><a href="<?php echo e(URL::to(Helper::admin_slug().'/dashboard')); ?>">Home</a></li>
						<li><i class="icon_profile"></i>Edit Profile</li>
					</ol>
				</div>
			</div>
              <!-- Form validations -->              
              <div class="row">
              <?php if(count($errors->all())>0): ?>
               <div class="col-lg-12">
                <div class="alert alert-block alert-danger fade in">
                      <?php echo HTML::ul($errors->all()); ?>

                     </div>
                    </div>
                   <?php endif; ?>
                  <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                              Profile Update
                          </header>
                          
                          <div class="panel-body">
                             
                           
                              <div class="form">
                              <?php foreach($userdata as $data): ?>
                        <form class="form-validate form-horizontal" id="profile_form" method="post" action="<?php echo e(URL::to(Helper::admin_slug().'/profile/userupdate')); ?>" enctype="multipart/form-data">
                                   <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                   <input type="hidden" name="uid" value="<?php echo e($data->id); ?>">
                                      <div class="form-group ">
                                          <label for="cname" class="control-label col-lg-2">Username <span class="required">*</span></label>
                                          <div class="col-lg-4">
                                       <input class="form-control" id="editusername" name="editusername" type="text" value="<?php echo e($data->username); ?>" />
                                          </div>
                                      </div>
                                      
                                      <div class="form-group ">
                                          <label for="cname" class="control-label col-lg-2">Full Name <span class="required">*</span></label>
                                          <div class="col-lg-4">
                                       <input class="form-control" id="editname" name="editname" type="text" value="<?php echo e($data->name); ?>" />
                                          </div>
                                      </div>

                                       <div class="form-group ">
                                          <label for="cname" class="control-label col-lg-2">Email <span class="required">*</span></label>
                                          <div class="col-lg-4">
                                       <input class="form-control" id="editemail" name="editemail" type="email" value="<?php echo e($data->email); ?>" />
                                          </div>
                                      </div>
                                      
                                      <div class="form-group ">
                                          <label for="ccomment" class="control-label col-lg-2">Select User Role</label>
                                          <div class="col-sm-2">
                                             <select class="form-control m-bot15" name="editrole" >
                                               <?php foreach($roles as $role): ?>
                                               <option value="<?php echo e($role->id); ?>" <?php if($role->id==$data->role_id){ echo "selected"; }?>><?php echo e($role->name); ?></option>
                                               <?php endforeach; ?>
                                          </select>
                                          </div>
                                      </div>
                                      <div class="form-group">
                                          <div class="col-lg-offset-2 col-lg-10">
                                              <button class="btn btn-primary" type="submit">Save</button>
                                          </div>
                                      </div>
                                  </form>
                                  <?php endforeach; ?>
                              </div>

                          </div>
                      </section>
                  </div>
              </div>
              
              <!-- page end-->
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>