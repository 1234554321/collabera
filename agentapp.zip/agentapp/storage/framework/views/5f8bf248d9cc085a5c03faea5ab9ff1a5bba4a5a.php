<?php if(Auth::check()): ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Admin">
    <meta name="author" content="">
    <meta name="keyword" content="Dashboard">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Admin</title>

    <!-- Bootstrap CSS 
    <link href="css/bootstrap.min.css" rel="stylesheet">-->    
     <?php echo HTML::style('css/bootstrap.min.css'); ?>

    <!-- bootstrap theme -->
   <?php echo HTML::style('css/bootstrap-theme.css'); ?>

    <!--colorpicker css-->
     <?php echo HTML::style('css/colorpicker.css'); ?>

    <!-- font icon -->
    <?php echo HTML::style('css/elegant-icons-style.css'); ?>

    <?php echo HTML::style('css/font-awesome.min.css'); ?>  
    <!-- full calendar css-->
   <?php echo HTML::style('assets/fullcalendar/fullcalendar/bootstrap-fullcalendar.css'); ?>

  <?php echo HTML::style('assets/fullcalendar/fullcalendar/fullcalendar.css'); ?>

    <!-- easy pie chart-->
   <?php echo HTML::style('assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css'); ?>

    <!-- owl carousel -->
   <?php echo HTML::style('css/owl.carousel.css'); ?>

   <?php echo HTML::style('css/jquery-jvectormap-1.2.2.css'); ?>

    <!-- Custom styles -->
  <?php echo HTML::style('css/fullcalendar.css'); ?>

  <?php echo HTML::style('css/widgets.css'); ?>

  <?php echo HTML::style('css/style.css'); ?>

  <?php echo HTML::style('css/style-responsive.css'); ?>

  <?php echo HTML::style('css/xcharts.min.css'); ?>

  <?php echo HTML::style('css/jquery-ui-1.10.4.min.css'); ?>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
      <script src="js/lte-ie7.js"></script>
    <![endif]-->
  </head>

  <body>
  <!-- container section start -->
  <section id="container" class="">
     <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('admin.include.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!--main content start-->
      <section id="main-content">
            <?php echo $__env->make('admin.partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <section class="wrapper">            
             <?php echo $__env->yieldContent('content'); ?>
          </section>
      </section>
      <!--main content end-->
  </section>
  <!-- container section start -->

    <!-- javascripts -->
     <?php echo HTML::script('js/jquery.js'); ?>

     <?php echo HTML::script('js/jquery-ui-1.10.4.min.js'); ?>

    <?php echo HTML::script('js/jquery-1.8.3.min.js'); ?>

    <?php echo HTML::script('js/jquery-ui-1.9.2.custom.min.js'); ?>

    
    <!--custom checkbox & radio-->
     <?php echo HTML::script('js/ga.js'); ?>

    <!--custom switch-->
      <?php echo HTML::script('js/bootstrap-switch.js'); ?>

    <!--custom tagsinput-->
     <?php echo HTML::script('js/jquery.tagsinput.js'); ?>

    <!-- colorpicker -->
      <?php echo HTML::script('js/colorpicker.js'); ?>

    <!-- bootstrap-wysiwyg -->
    <?php echo HTML::script('js/jquery.hotkeys.js'); ?>

     <?php echo HTML::script('js/bootstrap-wysiwyg.js'); ?>

    <?php echo HTML::script('js/bootstrap-wysiwyg-custom.js'); ?>

    <!-- tinymce editor -->
     <?php echo HTML::script('assets/tinymce/tinymce.min.js'); ?>

    <!-- custom form component script for this page-->
    <?php echo HTML::script('js/form-component.js'); ?>

    <!-- bootstrap -->
    <?php echo HTML::script('js/bootstrap.min.js'); ?>

    <!-- nice scroll -->
    <?php echo HTML::script('js/jquery.scrollTo.min.js'); ?>

   <?php echo HTML::script('js/jquery.nicescroll.js'); ?>

      <!-- jquery validate js -->
    <?php echo HTML::script('js/jquery.validate.min.js'); ?>

    <?php echo HTML::script('js/form-validation-script.js'); ?>

    <!-- charts scripts -->
   <?php echo HTML::script('assets/jquery-knob/js/jquery.knob.js'); ?>

   <?php echo HTML::script('js/jquery.sparkline.js'); ?>

   <?php echo HTML::script('assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js'); ?>

   <?php echo HTML::script('js/owl.carousel.js'); ?>

    <!-- jQuery full calendar -->
    <!-- Full Google Calendar - Calendar -->
      <?php echo HTML::script('js/fullcalendar.js'); ?>

    <?php echo HTML::script('assets/fullcalendar/fullcalendar/fullcalendar.js'); ?>

    <!--script for this page only-->
    <?php echo HTML::script('js/calendar-custom.js'); ?>

    <?php echo HTML::script('js/jquery.rateit.min.js'); ?>

    <!-- custom select -->
    <?php echo HTML::script('js/jquery.customSelect.min.js'); ?>

     <?php echo HTML::script('assets/chart-master/Chart.js'); ?>

    <!--custome script for all page-->
   <?php echo HTML::script('js/scripts.js'); ?>

    <!-- custom script for this page-->
   <?php echo HTML::script('js/sparkline-chart.js'); ?>

   <?php echo HTML::script('js/easy-pie-chart.js'); ?>

         <?php echo HTML::script('js/jquery-jvectormap-1.2.2.min.js'); ?>

        <?php echo HTML::script('js/jquery-jvectormap-world-mill-en.js'); ?>

       <?php echo HTML::script('js/xcharts.min.js'); ?>

        <?php echo HTML::script('js/jquery.autosize.min.js'); ?>

        <?php echo HTML::script('js/jquery.placeholder.min.js'); ?>

        <?php echo HTML::script('js/gdp-data.js'); ?>

       <?php echo HTML::script('js/morris.min.js'); ?>

        <?php echo HTML::script('js/sparklines.js'); ?>	
        <?php echo HTML::script('js/charts.js'); ?>

          <?php echo HTML::script('js/jquery.slimscroll.min.js'); ?>

         <?php echo HTML::script('js/customscripts.js'); ?>

  </body>
</html>
<?php else: ?>
 <?php echo $__env->make('admin.include.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>
