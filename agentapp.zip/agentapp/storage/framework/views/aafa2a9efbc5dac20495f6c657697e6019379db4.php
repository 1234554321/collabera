       
         <?php $__env->startSection('content'); ?>          
              <!--overview start-->
			 <div class="row">
				<div class="col-lg-12">
					<ol class="breadcrumb">
						<li><i class="fa fa-home"></i><a href="<?php echo e(URL::to(Helper::admin_slug().'/dashboard')); ?>">Home</a></li>
						<li><i class="icon_document_alt"></i>Edit Page</li>
					</ol>
				</div>
			</div>
              <!-- Form validations -->              
              <div class="row">
              <?php if(count($errors->all())>0): ?>
               <div class="col-lg-12">
                <div class="alert alert-block alert-danger fade in">
                      <?php echo HTML::ul($errors->all()); ?>

                     </div>
                    </div>
                   <?php endif; ?>
                  <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                              Edit Page
                          </header>
                          
                          <div class="panel-body">
                         
                              <div class="form">
                        <form class="form-validate form-horizontal" id="page_form" method="post" action="<?php echo e(URL::to(Helper::admin_slug().'/page/updateInfo')); ?>" enctype="multipart/form-data">
                                   <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                   <input type="hidden" name="id" value="<?php echo e($pages->id); ?>">
                                      <div class="form-group ">
                                          <label for="cname" class="control-label col-lg-2">Title <span class="required">*</span></label>
                                          <div class="col-lg-10">
                                       <input class="form-control" id="title" name="title" type="text" value="<?php echo e($pages->pagetitle); ?>" />
                                          </div>
                                      </div>
                                      <div class="form-group ">
                                          <label for="cemail" class="control-label col-lg-2">Content</label>
                                          <div class="col-lg-10">
                                     <textarea class="form-control " id="tinymce_textarea" name="cn"><?php echo $pages->content; ?></textarea>
                                          </div>
                                      </div>
                                      <div class="form-group ">
                                          <label for="curl" class="control-label col-lg-2">Image</label>
                                          <div class="col-sm-6">
                                              <input class="form-control " id="img" type="file" name="img" />
                                          </div>
                                           <img src='<?php echo e(url('uploads')); ?>/thumbnail<?php echo $pages->image; ?>'>
                                      </div>
                                      <div class="form-group ">
                                          <label for="cname" class="control-label col-lg-2">Meta Title <span class="required">*</span></label>
                                          <div class="col-lg-10">
                                              <input class="form-control" id="mt" name="mt" type="text" value="<?php echo e($pages->meta_title); ?>" />
                                          </div>
                                      </div> 
                                      <div class="form-group ">
                                          <label for="cname" class="control-label col-lg-2">Meta Keyword</label>
                                          <div class="col-lg-10">
                                              <input class="form-control" id="mk" name="mk" type="text" value="<?php echo e($pages->meta_keyword); ?>" />
                                          </div>
                                      </div>                                      
                                      <div class="form-group ">
                                          <label for="ccomment" class="control-label col-lg-2">Meta Description</label>
                                          <div class="col-lg-10">
                                              <textarea class="form-control" id="md" name="md"><?php echo $pages->meta_description; ?></textarea>
                                          </div>
                                      </div>
                                      
                                      <div class="form-group ">
                                          <label for="ccomment" class="control-label col-lg-2">Status</label>
                                          <div class="col-sm-2">
                                             <select class="form-control m-bot15" name="sts" >
                                              <?php if($pages->status==1): ?>
                                              <option value="1" selected>Active</option>
                                              <?php else: ?>
                                               <option value="1">Active</option>
                                               <?php endif; ?>
                                               <?php if($pages->status==2): ?>
                                              <option value="2" selected>Inactive</option>
                                              <?php else: ?>
                                               <option value="2">Inactive</option>
                                               <?php endif; ?>
                                          </select>
                                          </div>
                                      </div>
                                      <div class="form-group">
                                          <div class="col-lg-offset-2 col-lg-10">
                                              <button class="btn btn-primary" type="submit">Save</button>
                                          </div>
                                      </div>
                                  </form>
                              </div>

                          </div>
                      </section>
                  </div>
              </div>
              
              <!-- page end-->
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>