<div class="col-lg-12">
   <section class="panel">
    <form class="form-inline" method="post" name="agntfundadd" id="agntfundadd" action="<?php echo e(URL::to(Helper::admin_slug().'/agent/fund/save')); ?>" role="form">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
      <div class="form-group">
       <input type="number" class="form-control" id="addfund" name="addfund" value="" placeholder="Add fund">
       </div>
      <button type="submit" class="btn btn-primary">Add</button>
    
   <div class="table-responsive">
     <table class="table">
      <thead>
       <tr>
        <th>Date</th>
        <th>Fund</th>
       </tr>
     </thead>
     <?php if(isset($agentfund)): ?>
     <tbody>
      <?php foreach($agentfund as $getagentfund): ?>
       <tr>
        <td><?php echo $getagentfund->created_at; ?></td>
        <td>Rs. <?php echo $getagentfund->agnt_fund; ?></td>
       </tr>
      <?php endforeach; ?>
     </tbody>
     <input type="hidden" name="agntid" value="<?php echo $getagentfund->agnt_id; ?>">
     <?php else: ?>
     <input type="hidden" name="agntid" value="<?php echo $agentid; ?>">
     <?php endif; ?>
     </form>
   </section>
</div>