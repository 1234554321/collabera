       
         <?php $__env->startSection('content'); ?>   
          <?php $gng = Helper::shout(); //echo count($gng);?>
          <?php foreach($gng as $getuser): ?>
             <?php echo $getuser->name; ?>

          <?php endforeach; ?>      
              <!--overview start-->
			 <div class="row">
				<div class="col-lg-12">
					<h3 class="page-header"><i class="fa fa-files-o"></i> Pages</h3>
					<ol class="breadcrumb">
						<li><i class="fa fa-home"></i><a href="<?php echo e(URL::to(Helper::admin_slug())); ?>">Home</a></li>
						<li><i class="fa fa-table"></i>Pages</li>
					</ol>
				</div>
			</div>
              <!-- page start -->              
              <div class="row">
              <?php if(Session::has('message')): ?>
              <div class="col-lg-12">
                 <div class="alert alert-success fade in"><?php echo e(Session::get('message')); ?></div>
                  </div>
                  <?php endif; ?>
                  <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                              All Pages
                          </header>
                          <div class="table-responsive">
                            <table class="table">
                              <thead>
                                <tr>
                                  <th>No.</th>
                                  <th>Title</th>
                                  <th>Publish Date</th>
                                  <th>Status</th>
                                  <th>Action</th>
                                </tr>
                              </thead>
                              <tbody>
                              <?php foreach($pages as $getpage): ?>
                                <tr>
                                  <td><?php echo $getpage->id; ?></td>
                                  <td><?php echo $getpage->pagetitle; ?></td>
                                  <td><?php echo $getpage->created_at; ?></td>
                                  <td>
                                  <?php if($getpage->status==1): ?>
                                   <span class="label label-success">
                                     Active
                                     </span>
                                   <?php else: ?>
                                   <span class="label label-danger">
                                     Inactive
                                    </span>
                                   <?php endif; ?>
                                  </td>
                                  <td>
                                  <div class="btn-group">
                           <a class="btn btn-success" href="<?php echo e(URL::to(Helper::admin_slug().'/page/edit',array($getpage->id))); ?>" title="Edit">
                                      <i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                  <!--<a class="btn btn-success" href="#"><i class="icon_check_alt2"></i></a>-->
                                      <a class="btn btn-danger" href="<?php echo e(URL::to(Helper::admin_slug().'/page/delete',array($getpage->id))); ?>" title="Delete"><i class="icon_close_alt2"></i></a>
                                  </div>
                                  </td>
                                </tr>
                                <?php endforeach; ?>
                              </tbody>
                            </table>
                          </div>

                      </section>
                  </div>
              </div>
              <!-- page end-->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>